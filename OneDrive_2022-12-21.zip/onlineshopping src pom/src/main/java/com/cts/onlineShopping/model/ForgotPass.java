package com.cts.onlineShopping.model;

import lombok.Data;
import lombok.Generated;

@Generated
@Data
public class ForgotPass {
	
	private String LoginId;
	private boolean isUserAdmin;
	
}
