package com.cts.onlineShopping.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
//@EnableSwagger2
public class Config {
	
//	@Bean
//    public Docket api() { 
//        return new Docket(DocumentationType.SWAGGER_2)  
//          .select()                                  
//          .apis(RequestHandlerSelectors.basePackage("com.cts.onlineShopping"))              
//          .paths(PathSelectors.ant("api/v1.0/shopping*"))                          
//          .build();                          
//    }

}
